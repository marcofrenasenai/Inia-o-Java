
import java.util.Scanner;

public class atv4 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Insira o primeiro número: ");
        int num1 = sc.nextInt();
        System.out.print("Insira o segundo número: ");
        int num2 = sc.nextInt();

        for (int i = Math.min(num1, num2); i <= Math.max(num1, num2); i++) {
            if (ehPrimo(i)) {
                System.out.println(i + " é primo");
            }
        }
    }

    public static boolean ehPrimo(int num) {
        if (num < 2) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }
}
