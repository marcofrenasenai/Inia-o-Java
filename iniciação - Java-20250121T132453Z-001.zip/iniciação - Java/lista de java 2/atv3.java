
import java.util.Scanner;

public class atv3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        final String senhaCorreta = "1234";
        int tentativas = 0;

        while (tentativas < 3) {
            System.out.print("Insira a senha: ");
            String senha = sc.next();
            if (senha.equals(senhaCorreta)) {
                System.out.println("Acesso Permitido");
                return;
            } else {
                tentativas++;
            }
        }
        System.out.println("Acesso Negado");
    }
}
