
import java.util.Scanner;

public class atv6 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Quantos termos da sequência de Fibonacci deseja exibir? ");
        int n = sc.nextInt();

        int a = 0, b = 1;
        System.out.print(a + " " + b);
        for (int i = 2; i < n; i++) {
            int proximo = a + b;
            System.out.print(" " + proximo);
            a = b;
            b = proximo;
        }
    }
}
