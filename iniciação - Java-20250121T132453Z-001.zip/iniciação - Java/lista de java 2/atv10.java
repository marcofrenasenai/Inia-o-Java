
import java.util.Random;
import java.util.Scanner;

public class atv10 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();

        while (true) {
            System.out.print("Escolha: 1. Par 2. Ímpar 0. Sair: ");
            int escolha = sc.nextInt();
            if (escolha == 0) {
                break;
            }

            System.out.print("Insira um número: ");
            int numeroUsuario = sc.nextInt();
            int numeroComputador = rand.nextInt(10);

            int soma = numeroUsuario + numeroComputador;
            System.out.println("Computador escolheu: " + numeroComputador);
            System.out.println("Soma: " + soma);

            if ((soma % 2 == 0 && escolha == 1) || (soma % 2 != 0 && escolha == 2)) {
                System.out.println("Você venceu!");
            } else {
                System.out.println("Computador venceu!");
            }
        }
    }
}
