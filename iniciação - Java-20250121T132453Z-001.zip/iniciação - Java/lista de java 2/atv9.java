
import java.util.Random;
import java.util.Scanner;

public class atv9 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();
        int vitoriasUsuario = 0, vitoriasComputador = 0;

        while (true) {
            System.out.println("Escolha: 1. Pedra 2. Papel 3. Tesoura 0. Sair");
            int escolhaUsuario = sc.nextInt();
            if (escolhaUsuario == 0) {
                break;
            }

            int escolhaComputador = rand.nextInt(3) + 1;

            if (escolhaUsuario == escolhaComputador) {
                System.out.println("Empate!");
            } else if ((escolhaUsuario == 1 && escolhaComputador == 3)
                    || (escolhaUsuario == 2 && escolhaComputador == 1)
                    || (escolhaUsuario == 3 && escolhaComputador == 2)) {
                System.out.println("Você venceu!");
                vitoriasUsuario++;
            } else {
                System.out.println("Computador venceu!");
                vitoriasComputador++;
            }

            System.out.println("Placar: Você " + vitoriasUsuario + " x " + vitoriasComputador + " Computador");
        }
    }
}
