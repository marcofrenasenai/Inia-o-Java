
import java.util.Random;
import java.util.Scanner;

public class atv8 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();
        int numeroSecreto = rand.nextInt(100) + 1;
        int palpite;

        do {
            System.out.print("Adivinhe o número (entre 1 e 100): ");
            palpite = sc.nextInt();
            if (palpite < numeroSecreto) {
                System.out.println("Maior!");
            } else if (palpite > numeroSecreto) {
                System.out.println("Menor!");
            }
        } while (palpite != numeroSecreto);

        System.out.println("Você acertou!");
    }
}
