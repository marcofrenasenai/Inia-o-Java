
import java.util.Scanner;

public class atv2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int pares = 0, impares = 0;

        for (int i = 0; i < 10; i++) {
            System.out.print("Insira um número inteiro: ");
            int numero = sc.nextInt();
            if (numero % 2 == 0) {
                pares++;
            } else {
                impares++;
            }
        }

        System.out.println("Pares: " + pares);
        System.out.println("Ímpares: " + impares);
    }
}
