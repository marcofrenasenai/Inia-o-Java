
import java.util.Scanner;

public class atv7 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numero;

        do {
            System.out.print("Insira um número para ver sua tabuada (ou negativo para sair): ");
            numero = sc.nextInt();

            if (numero >= 0) {
                for (int i = 1; i <= 10; i++) {
                    System.out.println(numero + " x " + i + " = " + (numero * i));
                }
            }
        } while (numero >= 0);
    }
}
